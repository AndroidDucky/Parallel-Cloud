I did not do the extra credit and i used Qsort() for the sorting algorithm.
I ran my code on windows via command line using cygwin and visual studio code to write it. 
My time cost of this program should be N because I only used while/for loops without nesting them
The commands I ran on cmd line are
gcc main.c wordCount.c -o output
output.exe .\testfile1 
output.exe .\testfile2 (This is only if I ran the testfile 2)